<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\VehicleParts;
use Faker\Generator as Faker;

$factory->define(VehicleParts::class, function (Faker $faker) {
    return [
        //
    ];
});
