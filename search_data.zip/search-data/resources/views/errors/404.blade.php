<!DOCTYPE html>
<html lang="en">

<head>
    <title>Parts Europe</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>

<body>
    <h1>404</h1>
    <h2>Oops! Not Found</h2>
    <p>Please navigate to /vehicle</p>
    <a href="http://127.0.0.1:8000/vehicle">http://127.0.0.1:8000/vehicle</a>
    
</body>

</html>